FOLDER STRUCTURE :

 +--- admin_project/		#Upload all files to your hosting
 +--- android_project/
 +--- +--- Markeet/ 		#Open this folder from Android Studio
 +--- doc_admin/       		#Open index.html using browser (better on Firefox)
 +--- doc_android/		 	#Open index.html using browser (better on Firefox)
 
 * If your first time using Markeet you can import file database_markeet_demo.sql into your MySQL database
 * If you already using Markeet version 1.x, please execute query file patch_database_v2.0.sql


Thanks for purchasing my item :)