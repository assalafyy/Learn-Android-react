package com.app.markeet.connection.callbacks;

import com.app.markeet.model.NewsInfo;

import java.io.Serializable;

public class CallbackNewsInfoDetails implements Serializable {

    public String status = "";
    public NewsInfo news_info = null;

}
