package com.app.markeet.connection.callbacks;

import com.app.markeet.model.Product;

import java.io.Serializable;

public class CallbackProductDetails implements Serializable {

    public String status = "";
    public Product product = null;

}
